package com.lgy.ShoFriend.dao;

import java.util.HashMap;

public interface InfoDAO {
	public void updatePwd(HashMap<String, String> param);
	public void updateInfo(HashMap<String, String> param);
}
