package com.lgy.ShoFriend.dao;

import java.util.List;

import com.lgy.ShoFriend.dto.ProductDTO;

public interface ProductDAO { 
    public List<ProductDTO> getAllProducts();//목록 불러오는 테스트용 임시 메소드 입니다. 삭제해도됨.-25.04.10 권준우
}
