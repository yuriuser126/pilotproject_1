package com.lgy.ShoFriend.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgy.ShoFriend.dao.ProductDAO;
import com.lgy.ShoFriend.dto.ProductDTO;

@Service("ProductService")
public class ProductServiceImpl implements ProductService {
    @Autowired
    private SqlSession sqlSession;

    @Override
    public List<ProductDTO> getAllProducts() {
        ProductDAO dao = sqlSession.getMapper(ProductDAO.class);
        return dao.getAllProducts();
    }
}
